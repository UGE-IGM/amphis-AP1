def echange_peut_etre(a, b):
    """Essaie d'échanger les valeurs de a et b.
       Ça ne fonctionne pas..."""
    temp = a
    a = b
    b = temp


x = 1
y = 2
echange_peut_etre(x, y)
print(x, y)
print(temp)
